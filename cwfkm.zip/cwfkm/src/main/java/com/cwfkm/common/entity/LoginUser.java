package com.cwfkm.common.entity;

public class LoginUser {
	

}
