package com.cwfkm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CwfkmApplication {

	public static void main(String[] args) {
		SpringApplication.run(CwfkmApplication.class, args);
	}

}
