package com.cwfkm.service;

public interface ShiroService {
	String getUsernameInSubject();
}
