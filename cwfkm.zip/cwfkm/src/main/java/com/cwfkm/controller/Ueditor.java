package com.cwfkm.controller;

import lombok.Data;

@Data
public class Ueditor {
	private String state;
	private String url;
	private String title;
	private String original;
}
